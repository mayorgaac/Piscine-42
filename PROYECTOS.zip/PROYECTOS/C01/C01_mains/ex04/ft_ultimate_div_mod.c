/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/11 20:35:56 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/11 20:41:44 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int division = *a / *b;
	int resto = *a % *b;

	*a = division;
	*b = resto;

	printf("%d", *a);
	printf("%d", *b);
}

int main(){
	int num1 = 1;
	int num2 = 2;

	int *p_num1 = &num1;
	int *p_num2 = &num2;

	ft_ultimate_div_mod(p_num1,p_num2);
	return 0;
}
