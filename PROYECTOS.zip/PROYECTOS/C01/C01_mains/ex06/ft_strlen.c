/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/11 20:55:25 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/11 21:00:56 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int contador;

	contador = 0;
	while(*str)
	{
		contador++;
		str++;
	}
	return contador;
}

int main(){
	int len = ft_strlen("Hola mundo");

	printf("%d", len);
	return 0;
}
