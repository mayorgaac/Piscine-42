/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/11 19:58:38 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/13 20:24:32 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	printf("%p", &a);
	printf("%p", &b);

	int *temp;
	
	temp = a;
	a = b;
	b = temp;

	printf("%s", "\n");
	printf("%d", *a);
	printf("%d", *b);
	printf("%s", "\n");
	printf("%p", &a);
	printf("%p", &b);
}

int main(){
	
	int a = 1;
	int b = 2;

	int *c =&a;
	int *d = &b;


	ft_swap(c,d);
	return 0;
}
