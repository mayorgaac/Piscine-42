/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/11 21:03:06 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/12 19:21:14 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int contador = 0;
	int contador_rev = size -1;
	int temp;	

	while(contador < contador_rev)
	{
		/*printf("%d", contador);
		printf("%c", '\n');
		printf("%d", contador_rev);
		printf("%c", '\n');*/
		temp = tab[contador];
		tab[contador] = tab[contador_rev];
		tab[contador_rev] = temp;

		contador++;
		contador_rev--;
	}
	for (int i = 0; i < 5; i++)
    	 printf("%d ", tab[i]);

	printf("%c", '\n');
}

int main(){
	int array[5] = {1,2,3,4,5};
	ft_rev_int_tab(array, 5);
	return 0;
}
