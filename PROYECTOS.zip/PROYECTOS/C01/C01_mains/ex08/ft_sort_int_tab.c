/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 17:34:38 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/13 20:31:44 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int c1;

	c1 = 0;
	while(c1 < size)
	{
		int c2;
		int temp;

		c2 = c1 + 1;
		while (c2 < size)
		{
			if(tab[c1] > tab[c2])
			{
				temp = tab[c1];	
			   	tab[c1]= tab[c2];
				tab[c2] = temp ;
			}
			c2++;
		}
		c1++;
	}	

	for (int i = 0; i < size; i++)
	{
    	 printf("%d ", tab[i]);
    
	}
	printf("%c", '\n');

}


int main(void)
{
	int array[] = {13,2,8,5,1};
	ft_sort_int_tab(array,5);
	return 0;
}
