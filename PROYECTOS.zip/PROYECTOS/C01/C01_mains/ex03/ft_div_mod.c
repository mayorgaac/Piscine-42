/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/11 20:27:22 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/11 20:31:53 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;

	printf("%d", *div);
	printf("%d", *mod);
}

int main(){
	int d;
	int m;
	
	int *div = &d;
	int *mod = &m;

	ft_div_mod(4,2,div,mod);
	return 0;
}

