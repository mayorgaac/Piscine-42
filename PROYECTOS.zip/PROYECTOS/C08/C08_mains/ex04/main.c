
#include "ft_stock_str.h"

int main()
{
	char *tab[3];
	tab[0] = "HOLA MUNDO";
	tab[1] = "que tal";
	tab[2] = "Hello";

	t_stock_str *stock = ft_strs_to_tab(3,tab);
	ft_show_tab(stock);
}
