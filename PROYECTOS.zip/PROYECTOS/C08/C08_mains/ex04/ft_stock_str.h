/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stock_str.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/28 19:52:41 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/28 23:35:36 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef FT_STOCK_STR_H
#define FT_STOCK_STR_H

#include <stdlib.h>
#include <unistd.h>

typedef struct	s_stock_str
{
	int size;
	char *str;
	char *copy;
}	t_stock_str;

void ft_show_tab(struct s_stock_str *par);
struct s_stock_str *ft_strs_to_tab(int ac, char **av);

#endif
