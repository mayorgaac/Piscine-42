/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 18:27:50 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/24 14:18:07 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_prime(int nb)
{
	int	divisor;

	if (nb <= 1)
		return (0);
	else if (nb <= 3)
		return (1);
	if(nb % 2 == 0 || nb % 3 == 0)
		return (0);
	divisor = 5;
	while (divisor * divisor <= nb)
	{
		if(nb % divisor == 0 || nb % (divisor + 2) == 0)
			return (0);
		divisor += 6;
	}
	return (1);	
}

int	ft_find_next_prime(int nb)
{
	int	c;

	c = nb;
	if (nb <= 1)
		c = 2;
	while (c >= nb)
	{
		if (ft_is_prime(c) == 1)
		{
			return (c);
		}
		c++;
	}
	return (0);
}

#include <stdio.h>
int main()
{
	printf("%d\n", ft_find_next_prime(245826544));
	printf("%d\n", ft_find_next_prime(-256));
	printf("%d\n", ft_find_next_prime(0));
	printf("%d\n", ft_find_next_prime(3));
	printf("%d\n", ft_find_next_prime(7));
	printf("%d\n", ft_find_next_prime(33));
	printf("%d\n", ft_find_next_prime(2426544));
	return 0;

}

