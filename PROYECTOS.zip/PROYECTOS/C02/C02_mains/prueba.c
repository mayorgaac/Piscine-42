

#include <stdio.h>


void main(void){
	

	char a = '1';

	char *b = &a;
	
	printf("%s","\n");
	printf("%p",&b);
	printf("%s","\n");
	printf("%p",&a);
	printf("%s","\n");
	printf("%p",b);
	printf("%s","\n");
	printf("%d",*b);


	
}
