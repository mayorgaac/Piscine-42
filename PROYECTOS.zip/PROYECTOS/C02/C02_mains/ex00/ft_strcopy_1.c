/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcopy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/12 22:04:59 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/13 21:07:53 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strcopy(char *dest, char *src)
{
	char *origin;

	origin = dest;
	while(*src)
	{
/*		char c = src[c];
		write(1,c,1);
		write(1,"\n",1);*/
		*dest = *src;
		src++;
		dest++;
	}
	*dest = '\0';
	return origin;
}

int main() {
    char *src = "Hola Mundo";
    char dest[11]; // Espacio suficiente para "Hola Mundo" + el carácter nulo
    ft_strcopy(dest, src);

    // Escribir la cadena copiada en dest
    write(1, dest, 10); // Escribir los primeros 10 caracteres de dest
    write(1, "\n", 1);  // Escribir un salto de línea

    return 0;
}
