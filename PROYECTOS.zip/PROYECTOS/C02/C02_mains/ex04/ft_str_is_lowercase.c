/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 19:03:47 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/14 19:05:41 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */



#include <unistd.h>

int ft_str_is_lowercase(char *str) {
    
	int out;

	out = 0;
	if(*str == '\0')
	{
		return 1;
	}
	
	while (*str) {
        if (*str >= 'a' && *str <= 'z')
		{
            out = 1;
        }
		else
		{
			return 0;
		}
        str++;
    }
    return out;
}

int main(){
	
	char *str = "aaaaa";
	char *str2 = "asd123";
	char *str3 = "14as";
	char *str4 = "";
	char *str5 = "    \0";

	if(ft_str_is_lowercase(str) == 1){
		write(1, "Solo lowercase\n",15);
	}else{
		write(1, "Mas que lowercase\n",18);
	}
	if(ft_str_is_lowercase(str2) == 1){
		write(1, "Solo lowercase\n",15);
	}else{
		write(1, "Mas que lowercase\n",18);
	}
	if(ft_str_is_lowercase(str3) == 1){
		write(1, "Solo lowercase\n",15);
	}else{
		write(1, "Mas que lowercase\n",18);
	}
	if(ft_str_is_lowercase(str4) == 1){
		write(1, "Solo lowercase\n",15);
	}else{
		write(1, "Mas que lowercase\n",18);
	}
	if(ft_str_is_lowercase(str5) == 1){
		write(1, "Solo lowercase\n",15);
	}else{
		write(1, "Mas que lowercase\n",18);
	}
}
