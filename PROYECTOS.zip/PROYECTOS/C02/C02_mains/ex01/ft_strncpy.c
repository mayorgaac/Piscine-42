/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/13 21:17:29 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/15 18:08:51 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int c;

	c = 0;
	while(csrc[c] != '\0' && c < n)
	{
		dest[c] = src[c];
		c++;
	}
	while(c < n)
	{
		dest[c] = '\0';
		c++;
	}
	return dest;
	
}

int main() {
    char src[] = "Hello World";
    char dest[20]; // Espacio suficiente para contener la cadena de origen

    ft_strncpy(dest, src, 5); // Copia los primeros 5 caracteres de src en dest

    // Escribir la cadena copiada en la salida estándar
    write(1, dest, 5); // Escribir los primeros 5 caracteres de dest
    write(1, "\n", 1); // Escribir un salto de línea

    return 0;
}
