/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 19:01:05 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/14 19:01:23 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_str_is_alpha(char *str) {
    
	int out;

	out = 0;
	if(*str == '\0')
	{
		return 1;
	}
	
	while (*str) {
        if (*str >= 'A' && *str <= 'Z')
		{
            out = 1;
        }
		else if(*str >= 'a' && *str <= 'z')
		{
            out = 1;
		}
		else
		{
			return 0;
		}
        str++;
    }
    return out;
}

int main(){
	
	char *str = "HelloWorld";
	char *str2 = "123asd";
	char *str3 = "";
	char *str4 = "    \0";

	if(ft_str_is_alpha(str) == 1){
		write(1, "Solo letras\n",12);
	}else{
		write(1, "Mas que letras\n",15);
	}

	if(ft_str_is_alpha(str2) == 1){
		write(1, "Solo letras\n",12);
	}else{
		write(1, "Mas que letras\n",15);
	}
	
	if(ft_str_is_alpha(str3) == 1){
		write(1, "Solo letras\n",12);
	}else{
		write(1, "Mas que letras\n",15);
	}
	
	if(ft_str_is_alpha(str4) == 1){
		write(1, "Solo letras\n",12);
	}else{
		write(1, "Mas que letras\n",15);
	}
}
