/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 19:08:51 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/14 19:09:11 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_str_is_printable(char *str) {
    
	int out;

	out = 0;
	if(*str == '\0')
	{
		return 1;
	}
	
	while (*str) {
        if (*str > 31 && *str < 127)
		{
            out = 1;
        }
		else
		{
			return 0;
		}
        str++;
    }
    return out;
}

int main() {
    char test_str1[] = "Hello, World!"; // Cadena que contiene solo caracteres imprimibles
    char test_str2[] = "Hello\nWorld!"; // Cadena que contiene un carácter no imprimible (\n)

    if (ft_str_is_printable(test_str1) == 1) {
        write(1, "La cadena contiene solo caracteres imprimibles.\n", 49);
    } else {
        write(1, "La cadena contiene caracteres que no son imprimibles.\n", 57);
    }

    if (ft_str_is_printable(test_str2) == 1) {
        write(1, "La cadena contiene solo caracteres imprimibles.\n", 49);
    } else {
        write(1, "La cadena contiene caracteres que no son imprimibles.\n", 57);
    }

    return 0;
}
