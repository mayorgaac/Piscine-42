/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 19:41:23 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/15 19:04:13 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int islowercase(char c)
{
	if( c >= 'a' && c <= 'z')
	{
		return 1;
	}
	return 0;
}


char *ft_strupcase(char *str)
{
	int salto;
	int c;

	salto = 'A' - 'a';
	c = 0;
	while(str[c] != '\0')
	{
		if(islowercase(str[c])==1)
		{
			str[c] = str[c] + salto;
		}
		c++;
	}

	return str;
}

int main()
{
	char str[] = "";
	char *outstr;

	outstr = ft_strupcase(str);

	while(*outstr){
		write(1,outstr,1);
		outstr++;
	}

	return 0;
}
