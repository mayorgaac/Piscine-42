/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 20:06:53 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/22 22:45:33 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int isalphanumeric(char c)
{
	if((c >= 'a' && c <= 'z' )  || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
	{
		return 1;
	}
	return 0;
}

int islowercase(char c)
{
	if(c >= 'a' && c <= 'z')
	{
		return 1;
	}
	return 0;
}

char *ft_strcapitalize(char *str)
{
	int salto;
	int c;

	salto = 'A' - 'a';
	c = 0;

	while(str[c] != '\0')
	{
		if(c == 0 && islowercase(str[c]) == 1)
		{
			str[c] = str[c] + salto;
		}
		else
		{
			if(isalphanumeric(str[c - 1]) == 0 && islowercase(str[c]) == 1 )
			{
				str[c] = str[c] + salto;
			}
		}
		c++;
	}

	return str;
}

int main(){
	char str[] = "salut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	char *outstr;

	outstr = ft_strcapitalize(str);

	while(*outstr){
		write(1,outstr,1);
		outstr++;
	}
	
	return 1;
}
