/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 21:05:40 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/14 21:46:46 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

unsigned int ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int c;
	unsigned int src_len;

	c = 0;
	while(c < size && src[c] != '\0')
	{
		dest[c] = src[c];
		c++;
	}
	dest[c] = '\0';
	src_len = 0;
	while(src[src_len] != '\0')
	{
		src_len++;
	}
	return src_len;
}

int main() {
    char src[] = "Esta cadena es más larga que el búfer de destino";
    char dest[20]; // Definir un búfer de destino más pequeño que la cadena de origen

    // Llamada a la función ft_strlcpy
    ft_strlcpy(dest, src, sizeof(dest));

    // La función ft_strlcpy no devuelve la longitud de la cadena original
    // Entonces no podemos verificar el desbordamiento directamente desde la función

    // Imprimir el búfer de destino para ver el desbordamiento
    write(1, dest, sizeof(dest));

    return 0;
}
