/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/14 19:02:00 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/14 19:03:28 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */



#include <unistd.h>

int ft_str_is_numeric(char *str) {
    
	int out;

	out = 0;
	if(*str == '\0')
	{
		return 1;
	}
	
	while (*str) {
        if (*str >= '0' && *str <= '9')
		{
            out = 1;
        }
		else
		{
			return 0;
		}
        str++;
    }
    return out;
}

int main(){
	
	char *str = "12345";
	char *str2 = "asd123";
	char *str3 = "14as";
	char *str4 = "";
	char *str5 = "    \0";

	if(ft_str_is_numeric(str) == 1){
		write(1, "Solo numeros\n",13);
	}else{
		write(1, "Mas que numeros\n",16);
	}

	if(ft_str_is_numeric(str2) == 1){
		write(1, "Solo numeros\n",13);
	}else{
		write(1, "Mas que numeros\n",16);
	}
	
	if(ft_str_is_numeric(str3) == 1){
		write(1, "Solo numeros\n",13);
	}else{
		write(1, "Mas que numeros\n",16);
	}
	
	if(ft_str_is_numeric(str4) == 1){
		write(1, "Solo numeros\n",13);
	}else{
		write(1, "Mas que numeros\n",16);
	}
	
	if(ft_str_is_numeric(str5) == 1){
		write(1, "Solo numeros\n",13);
	}else{
		write(1, "Mas que numeros\n",16);
	}
}
