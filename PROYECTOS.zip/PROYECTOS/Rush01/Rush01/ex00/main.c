/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/17 09:53:43 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/18 15:23:16 by gorodrig         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	init_board(int *input);

int	check_input(char *arg, int *input);

int	main(int argc, char *argv[])
{
	int	input[16];

	if (argc == 2)
	{
		if (check_input(argv[1], input) == 16)
			init_board(input);
	}
	else if (argc == 1)
	{
		write(2, "\nERROR: Introduce un argumento.\n", 32);
	}
	else
	{
		write(2, "\nERROR: Introduce un solo argumento.\n", 37);
	}
}
