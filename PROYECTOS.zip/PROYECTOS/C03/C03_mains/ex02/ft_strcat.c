/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/15 23:04:00 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/18 20:30:43 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char *ft_strcat(char *dest, char *src)
{
	int i;

	i = 0;
	while(dest[i] != '\0')
	{
		i++;
	}
	while(*src)
	{
		dest[i] = *src;
		src++;
   		i++;	   
	}
	dest[i] = '\0';
	return (dest);
}

int main() {

	char dest[20] = "Hello, ";
    char src[] = "world!";

    // Concatena la cadena src al final de la cadena dest
    ft_strcat(dest, src);

    // Imprime la cadena resultante
    write(1, dest, sizeof(dest) - 1); // Excluir el carácter nulo extra agregado




/*	// Caso 1: Cadena de destino demasiado pequeña
    // Esto debería provocar un desbordamiento del búfer
    char dest[10] = "Hello";
    char src[] = "world!";
	ft_strcat(dest, src);

    // Caso 2: Cadena de origen nula
    // Se espera que no ocurra nada, ya que no hay nada que concatenar
    char dest2[10] = "Hello";
    char *src2 = NULL;
    ft_strcat(dest2, src2);

    // Caso 3: Cadena de destino nula
    // Esto debería provocar un comportamiento indefinido
    char *dest3 = NULL;
    char src3[] = "world!";
    ft_strcat(dest3, src3);

    // Caso 4: Desbordamiento del buffer
    // Intentaremos concatenar una cadena de longitud mayor que el tamaño del destino
    char dest4[5] = "Hello";
    char src4[] = "world!";
    ft_strcat(dest4, src4);
*/
    return 0;
}
