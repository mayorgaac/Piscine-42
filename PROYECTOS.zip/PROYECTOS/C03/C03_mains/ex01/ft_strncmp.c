/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/15 22:49:37 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/18 20:28:03 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int c;

	c = 0;
	while (s1[c] != '\0' && s2[c] != '\0' && s1[c] == s2[c] && c < n - 1)
	{
		c++;
	}
	return (s1[c] - s2[c]);
}

int main() {
    char str1[] = "hello";
    char str2[] = "helicopter";
    unsigned int n = 3;
    int result = ft_strncmp(str1, str2, n);

    if (result < 0) {
        write(1, "str1 es menor que str2\n", 24);
    } else if (result == 0) {
        write(1, "str1 es igual a str2\n", 22);
    } else {
        write(1, "str1 es mayor que str2\n", 24);
    }

    return 0;
}
