/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/15 22:20:46 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/18 20:21:54 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int ft_strcmp(char *s1, char *s2)
{
	int c;

	c = 0;
	while (s1[c] != '\0' && s2[c] != '\0' && s1[c] == s2[c])
	{
		c++;
	}		
	return (s1[c] - s2[c]);
}

int main() {
    char str1[] = "z";
    char str2[] = "z";
    int result;

    result = ft_strcmp(str1, str2);

    if (result < 0) {
        write(1, "str1 es menor que str2\n", 24);
    } else if (result == 0) {
        write(1, "str1 es igual a stizr2\n", 22);
    } else {
        write(1, "str1 es mayor que str2\n", 24);
    }

    return 0;
}
