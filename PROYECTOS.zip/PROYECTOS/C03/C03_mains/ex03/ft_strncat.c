/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/15 23:21:23 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/18 20:34:10 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char *ft_strncat(char *dest, char *src, unsigned int nb)
{
	int i;
	unsigned int c;

	i = 0;
	c = 0;
	while(dest[i] != '\0')
	{
		i++;
	}
	while(*src != '\0' && c < nb)
	{
		dest[i++] = *src++;
		c++;
	}
	dest[i] = '\0';
	return (dest);
}

int main()
{
 	char dest[20] = "Hello, ";
    char src[] = "world!";
    unsigned int nb = 10;

    // Concatena hasta nb caracteres de src al final de dest
    ft_strncat(dest, src, nb);

    // Imprime la cadena resultante
    write(1, dest, sizeof(dest) - 1); // Excluir el carácter nulo extra agregado

    return 0;
}
