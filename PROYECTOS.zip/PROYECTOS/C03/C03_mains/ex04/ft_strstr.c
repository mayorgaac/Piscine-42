/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/15 23:38:13 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/18 20:34:58 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char *ft_strstr(char *str, char *to_find)
{
	int i;
	char *temp;
	
	temp = str;
	if(*to_find == '\0')
		return (str);
	while (*temp)
	{
		i = 0;
		if(*temp == to_find[0])
		{
			while (temp[i] == to_find[i] && to_find[i])
				i++;
			if(to_find[i] == '\0')
				return (temp);
		}
		temp++;
	}
	return (0);
}

int main() {
    char str[] = "Hello, world!";
    char to_find[] = "world";

    // Probando la función original strstr
    printf("Resultado de strstr: %s\n", strstr(str, to_find));

    // Probando la función personalizada ft_strstr
    printf("Resultado de ft_strstr: %s\n", ft_strstr(str, to_find));

    return 0;
}
