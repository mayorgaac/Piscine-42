/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carlsanc <carlsanc@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/27 12:28:59 by carlsanc          #+#    #+#             */
/*   Updated: 2024/02/27 12:55:53 by carlsanc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./BSQ.h"

void	init_data(t_data *data)
{
	data->nbr_lines = 0;
	data->len_lines = 0;
	data->bsq_x = 0;
	data->bsq_y = 0;
	data->map = NULL;
}

unsigned short	**init_square(t_data *d)
{
	unsigned short	**square;
	unsigned int	i;

	square = malloc(sizeof(unsigned short *) * d->nbr_lines);
	if (!square)
	{
		ft_putstr("Error: Malloc failed\n");
		return (NULL);
	}
	i = 0;
	while (i < d->nbr_lines)
	{
		square[i] = malloc(sizeof(unsigned short) * d->len_lines);
		if (!square[i])
			return (free_square_i(square, i));
		i++;
	}
	return (square);
}
