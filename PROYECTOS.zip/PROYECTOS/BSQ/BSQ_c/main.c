/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carlsanc <carlsanc@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/27 12:29:10 by carlsanc          #+#    #+#             */
/*   Updated: 2024/02/27 12:54:38 by carlsanc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./BSQ.h"

int	clear(t_data *data, unsigned short **square, int ret)
{
	if (data->map)
		free(data->map);
	if (square)
		free_square(square, data);
	return (ret);
}

int	solve(t_data *data, char *file)
{
	unsigned short	**square;

    printf("%s", "Llego aqui");
	init_data(data);
    if (!file)
    {
        if (!read_stdin(data))
            return (clear(data, NULL, 0));
    }
    else
    {
        if (!read_file(data, file))
            return (clear(data, NULL, 0));
    }
	square = init_square(data);
	if (!square)
        return (clear(data, NULL, 0));
	if (!process(data, square))
		return (clear(data, square, 0));
	if (PRINT == 0)
		display_bsq(data, square);
	return (clear(data, square, 1));
}

int	main(int argc, char *argv[])
{
	t_data	data;
	int		i;

    printf("%s", "Llego aqui");
	if (argc > 1)
	{
		i = 1;
		while (i < argc && solve(&data, argv[i]))
			i++;
		if (i < argc)
			return (1);
	}
	else
		return (solve(&data, NULL));
	return (0);
}
