/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carlsanc <carlsanc@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/27 12:29:47 by carlsanc          #+#    #+#             */
/*   Updated: 2024/02/27 12:54:34 by carlsanc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./BSQ.h"

static int	ft_strlen(const char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_putstr(char *str)
{
	(void)!write(2, str, ft_strlen(str));
	return (0);
}

static int	ft_strcpy(char *dst, const char *src, const size_t size)
{
	size_t	i;

	i = 0;
	while (i < size && src[i])
	{
		dst[i] = src[i];
		i++;
	}
	dst[i] = '\0';
	return (i);
}

char	*ft_strjoin_bsq(char *s1, const size_t size1,
		char *s2, const size_t size2)
{
	char	*res;

	res = (char *)malloc(sizeof(char) * (size1 + size2 + 1));
	if (!res)
		return (NULL);
	ft_strcpy(res, s1, size1);
	ft_strcpy(&res[size1], s2, size2);
	free(s1);
	return (res);
}

void    free_square(unsigned short **square, t_data *data)
{
    unsigned int    i;

    i = 0;
    while (i < data->nbr_lines)
    {
        free(square[i]);
        i++;
    }
    if (data->len_lines != 0)
        free(square);
}

unsigned short    **free_square_i(unsigned short **square, int i)
{
    while (--i >= 0)
        free(square[i]);
    free(square);
    return (NULL);
}
