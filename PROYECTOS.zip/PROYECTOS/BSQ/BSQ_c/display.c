/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carlsanc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/27 12:28:49 by carlsanc          #+#    #+#             */
/*   Updated: 2024/02/27 12:28:52 by carlsanc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./BSQ.h"

static void	print_bsq(t_data *data)
{
	(void)!write(1, &data->map[data->n], data->nbr_lines * (data->len_lines + 1));
}

void    print_debug(t_data *data, unsigned short **square)
{
	unsigned int	x;
	unsigned int	y;

	printf("\n");
	y = 0;
	while (y < data->nbr_lines)
	{
		x = 0;
		while (x < data->len_lines)
		{
			printf("%d", square[y][x]);
			x++;
		}
		y++;
		printf("\n");
	}
}

static void	paint_bsq(t_data *data, unsigned short **square)
{
	unsigned int	x;
	unsigned int	y;
	unsigned int	top_left_x;
	unsigned int	top_left_y;

	top_left_x = data->bsq_x - square[data->bsq_y][data->bsq_x] + 1;
	top_left_y = data->bsq_y - square[data->bsq_y][data->bsq_x] + 1;
	y = 0;
	while (y <= data->nbr_lines)
	{
		x = 0;
		while (x <= data->len_lines)
		{
			if ((y >= top_left_y && y <= data->bsq_y)
				&& (x >= top_left_x && x <= data->bsq_x))
				data->map[(y * (data->len_lines + 1)) + x + data->n] = data->filler;
			x++;
		}
		y++;
	}
}

void	display_bsq(t_data *data, unsigned short **square)
{
	paint_bsq(data, square);
	print_bsq(data);
	if (DEBUG != 0)
		print_debug(data, square);
}
