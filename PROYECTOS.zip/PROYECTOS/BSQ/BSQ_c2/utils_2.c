/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carlsanc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/28 11:59:08 by carlsanc          #+#    #+#             */
/*   Updated: 2024/02/28 12:00:40 by carlsanc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./BSQ.h"

void	free_square(unsigned short **square, t_data *data)
{
	unsigned int	i;

	i = 0;
	while (i < data->nbr_lines)
	{
		free(square[i]);
		i++;
	}
	if (data->len_lines != 0)
		free(square);
}

unsigned short	**free_square_i(unsigned short **square, int i)
{
	while (--i >= 0)
		free(square[i]);
	free(square);
	return (NULL);
}
