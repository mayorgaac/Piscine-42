/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: carlsanc <carlsanc@student.42madrid.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/27 12:29:27 by carlsanc          #+#    #+#             */
/*   Updated: 2024/02/28 12:15:30 by carlsanc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./BSQ.h"

int	read_big_map(t_data *d, int fd, size_t buffer_size, size_t size)
{
	char	*buffer;
	ssize_t	ret;

	buffer = (char *)malloc(sizeof(char) * buffer_size + 1);
	if (!buffer)
		return (ft_putstr("Error: Malloc failed\n"));
	ret = read(fd, buffer, buffer_size);
	buffer[ret] = '\0';
	while (ret != 0 && ret != EOF)
	{
		d->map = ft_strjoin_bsq(d->map, size, buffer, buffer_size);
		if (!d->map)
			return (ft_putstr("Error: Malloc failed\n"));
		size += ret;
		ret = read(fd, buffer, buffer_size);
		buffer[ret] = '\0';
	}
	free(buffer);
	return (1);
}

int	read_map(t_data *d, int fd, size_t buffer_size)
{
	ssize_t		ret;

	d->map = (char *)malloc(sizeof(char) * BUFFER_INIT + 1);
	if (!d->map)
		return (ft_putstr("Error: Malloc failed\n"));
	ret = read(fd, d->map, BUFFER_INIT);
	d->map[ret] = '\0';
	if (ret != 0 && ret != EOF)
		if (!read_big_map(d, fd, buffer_size, ret))
			return (0);
	return (1);
}

int	map_arg(t_data *d)
{
	unsigned int	i;
	unsigned int	x;

	i = 0;
	while (d->map[i] && d->map[i] != '\n')
		i++;
	if (i < 4)
		return (ft_putstr("Error: map error\t(invalid map arguments)"));
	if (!d->map[i] || !d->map[i + 1])
		return (ft_putstr("Err: map error\t(file need more than one line)\n"));
	d->n = i + 1;
	d->fill = d->map[--i];
	d->obstac = d->map[--i];
	d->empty = d->map[--i];
	if (d->empty == d->fill || d->empty == d->obstac || d->fill == d->obstac)
		return (ft_putstr("Error: map error\t(map char can't be the same)\n"));
	x = 0;
	d->nbr_lines = 0;
	while (x < i)
	{
		if (d->map[x] > '9' || d->map[x] < '0')
			return (ft_putstr("Err: map error\t(nbr_lines isn't a number)\n"));
		d->nbr_lines = d->nbr_lines * 10 + d->map[x++] - '0';
	}
	return (1);
}
