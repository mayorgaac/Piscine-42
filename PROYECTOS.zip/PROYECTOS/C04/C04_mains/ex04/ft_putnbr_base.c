/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 23:26:10 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/20 19:25:53 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int len(char *base)
{
	int c;
	char *temp;

	temp = base;
	c = 0;
	while(*temp)
	{
		c++;
		temp++;
	}
	return c;
}

int validaciones(char *base)
{
	int i;
	int j;

	if(base[0] != '\0' &&  base[1] == '\0')
		return (0);
	i = 0;
	while(base[i] != '\0')
	{
		if(base[i] == '+' || base[i] == '-')
				return (0);
		j = i + 1;
		while(base[j] != '\0')
		{
			if(base[i]==base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);

}	

void ft_putnbr_base(int nbr, char *base)
{
	int signo;
	int longitud;
	char output;

	if(validaciones(base) == 1)
	{
		if (nbr < 0)
		{
			signo = -1;
			write(1, "-", 1);
			nbr = -nbr;
		}
		longitud = len(base);

		if (nbr >= longitud)
		{
			ft_putnbr_base(nbr / longitud, base);
			ft_putnbr_base(nbr % longitud, base);
		}
		else
		{
			output = base[nbr % longitud];
			write(1, &output, 1);		
		}
	}
}

int main()
{
    //ME PARECE QUE NO FUNCIONA
	
	char base1[] = "0123456789ABCDEF";
    char base2[] = "01";
    char base3[] = "Ol";

    int number1 = 1234;
    int number2 = 1234;
    int number3 = 1234;

    ft_putnbr_base(number1, base1);
    write(1, "\n", 1);
    ft_putnbr_base(number2, base2);
    write(1, "\n", 1);
    ft_putnbr_base(number3, base3);
    write(1, "\n", 1);

    return 0;
}
