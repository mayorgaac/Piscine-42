/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 22:21:16 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/19 22:24:10 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putstr(char *str)
{
	int i;

	i = 0;
	while (*str)
	{
		write(1, str, 1);
		str++;
	}
}

int main(){
	
	char str[] = "hola mundo";
	ft_putstr(str);
	return 0;
}
