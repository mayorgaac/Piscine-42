/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 22:15:02 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/19 22:19:00 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while(*str)
	{
		i++;
		str++;
	}
	return (i);
}

int main()
{
	char str[] = "\0";
	int len = ft_strlen(str);

	printf("%d", len);
}
