/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: amayorga <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 22:50:31 by amayorga          #+#    #+#             */
/*   Updated: 2024/02/20 18:47:37 by amayorga         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void signo(char *str, int *c_signo, int *index)
{
	while(str[*index] == '-' || str[*index] == '+')
	{
		if(str[*index] == '-')
			(*c_signo)++;	
		(*index)++;
	}
}

int ft_atoi(char *str)
{
	int c_signo;
	int index;
	int output;

	c_signo = 0;
	index = 0;
	output = 0;
	while((str[index] >= 9 && str[index] <= 13) || str[index] == 32)
		index++;

	signo(str, &c_signo, &index);	

	while (str[index] >= '0' && str[index] <= '9')
	{
		output = output * 10 + (str[index] - '0');
		index++;
	}
	if(c_signo % 2 != 0)
		output = -output;
	return (output);
}

int main() {
   // char str[] = " ---+--+1234ab567";
    char str[] = "  	--++---12347";

    // Usando ft_atoi
    int resultado_ft_atoi = ft_atoi(str);
    printf("Resultado de ft_atoi: %d\n", resultado_ft_atoi);

    // Usando atoi
    int resultado_atoi = atoi(str);
    printf("Resultado de atoi: %d\n", resultado_atoi);

    return 0;
}
