#!/bin/sh
ls -a | wc -w | cut -c 8-
